#include "mainwindow.h"
#include "iniciar.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   // MainWindow w;
    Iniciar w;
    w.show();
    return a.exec();
}
