#include "iniciar.h"
#include "ui_iniciar.h"
#include"mainwindow.h"

Iniciar::Iniciar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Iniciar)
{
    ui->setupUi(this);
}

Iniciar::~Iniciar()
{
    delete ui;
}



void Iniciar::on_pushButton_19_clicked()
{
   hide();
    mainwindow = new MainWindow(this);
    mainwindow ->show();

}

void Iniciar::on_pushButton_20_clicked()
{
    close();
}
