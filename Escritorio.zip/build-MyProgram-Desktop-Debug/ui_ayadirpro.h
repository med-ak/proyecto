/********************************************************************************
** Form generated from reading UI file 'ayadirpro.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AYADIRPRO_H
#define UI_AYADIRPRO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_ayadirpro
{
public:
    QGridLayout *gridLayout;
    QPushButton *pushButton_2;
    QSpacerItem *verticalSpacer;
    QLineEdit *lineEdit_7;
    QPushButton *pushButton;
    QLabel *label_7;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_4;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QPushButton *pushButton_3;
    QLineEdit *lineEdit_6;
    QLabel *label_8;
    QPushButton *pushButton_4;
    QLineEdit *lineEdit_3;
    QSpacerItem *horizontalSpacer;

    void setupUi(QDialog *ayadirpro)
    {
        if (ayadirpro->objectName().isEmpty())
            ayadirpro->setObjectName(QStringLiteral("ayadirpro"));
        ayadirpro->resize(750, 276);
        gridLayout = new QGridLayout(ayadirpro);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        pushButton_2 = new QPushButton(ayadirpro);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(200, 50));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        pushButton_2->setFont(font);

        gridLayout->addWidget(pushButton_2, 4, 3, 2, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 7, 1, 1, 1);

        lineEdit_7 = new QLineEdit(ayadirpro);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        QFont font1;
        font1.setPointSize(12);
        lineEdit_7->setFont(font1);

        gridLayout->addWidget(lineEdit_7, 6, 1, 1, 1);

        pushButton = new QPushButton(ayadirpro);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setMinimumSize(QSize(200, 50));
        pushButton->setFont(font);

        gridLayout->addWidget(pushButton, 0, 3, 2, 1);

        label_7 = new QLabel(ayadirpro);
        label_7->setObjectName(QStringLiteral("label_7"));
        QFont font2;
        font2.setPointSize(14);
        label_7->setFont(font2);
        label_7->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(label_7, 5, 0, 1, 1);

        label_5 = new QLabel(ayadirpro);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font2);
        label_5->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(label_5, 3, 0, 2, 1);

        label_6 = new QLabel(ayadirpro);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setFont(font2);
        label_6->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(label_6, 1, 0, 2, 1);

        label_4 = new QLabel(ayadirpro);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setFont(font2);
        label_4->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(label_4, 0, 0, 1, 1);

        lineEdit_4 = new QLineEdit(ayadirpro);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setFont(font1);

        gridLayout->addWidget(lineEdit_4, 1, 1, 2, 1);

        lineEdit_5 = new QLineEdit(ayadirpro);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setFont(font1);

        gridLayout->addWidget(lineEdit_5, 3, 1, 2, 1);

        pushButton_3 = new QPushButton(ayadirpro);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(200, 50));
        pushButton_3->setFont(font);

        gridLayout->addWidget(pushButton_3, 6, 3, 1, 1);

        lineEdit_6 = new QLineEdit(ayadirpro);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setFont(font1);

        gridLayout->addWidget(lineEdit_6, 5, 1, 1, 1);

        label_8 = new QLabel(ayadirpro);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setFont(font2);
        label_8->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(label_8, 6, 0, 1, 1);

        pushButton_4 = new QPushButton(ayadirpro);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(200, 50));
        pushButton_4->setFont(font);

        gridLayout->addWidget(pushButton_4, 2, 3, 2, 1);

        lineEdit_3 = new QLineEdit(ayadirpro);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setFont(font1);

        gridLayout->addWidget(lineEdit_3, 0, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 2, 2, 1, 1);


        retranslateUi(ayadirpro);

        QMetaObject::connectSlotsByName(ayadirpro);
    } // setupUi

    void retranslateUi(QDialog *ayadirpro)
    {
        ayadirpro->setWindowTitle(QApplication::translate("ayadirpro", "Dialog", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("ayadirpro", "Borrar ", Q_NULLPTR));
        pushButton->setText(QApplication::translate("ayadirpro", "Guardar", Q_NULLPTR));
        label_7->setText(QApplication::translate("ayadirpro", "PrecioPorUnidad", Q_NULLPTR));
        label_5->setText(QApplication::translate("ayadirpro", "Cantidad", Q_NULLPTR));
        label_6->setText(QApplication::translate("ayadirpro", "Codigo de barras", Q_NULLPTR));
        label_4->setText(QApplication::translate("ayadirpro", "Nombre", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("ayadirpro", "Salir", Q_NULLPTR));
        label_8->setText(QApplication::translate("ayadirpro", "PrecioTotal", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("ayadirpro", "Modificar", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ayadirpro: public Ui_ayadirpro {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AYADIRPRO_H
