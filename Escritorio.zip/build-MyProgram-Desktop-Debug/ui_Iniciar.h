/********************************************************************************
** Form generated from reading UI file 'Iniciar.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INICIAR_H
#define UI_INICIAR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *home;
    QWidget *tab0;
    QDateTimeEdit *dateTimeEdit;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QWidget *tab1;
    QTableWidget *tableWidget;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QLineEdit *lineEdit_4;
    QFrame *line;
    QLineEdit *lineEdit_5;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton_5;
    QWidget *tab2;
    QLabel *label_10;
    QFrame *line_2;
    QLineEdit *lineEdit_6;
    QLabel *label_11;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_8;
    QLabel *label_12;
    QTableWidget *tableWidget_2;
    QPushButton *pushButton_9;
    QPushButton *pushButton_6;
    QPushButton *pushButton_8;
    QPushButton *pushButton_7;
    QWidget *tab3;
    QTableWidget *tableWidget_4;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QLabel *label_13;
    QLabel *label_14;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_10;
    QFrame *line_4;
    QPushButton *pushButton_17;
    QPushButton *pushButton_18;
    QLineEdit *lineEdit_11;
    QLabel *label_15;
    QWidget *tab4;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QFrame *line_3;
    QPushButton *pushButton_12;
    QTableWidget *tableWidget_3;
    QPushButton *pushButton_13;
    QDateEdit *dateEdit_5;
    QLabel *label_30;
    QDateEdit *dateEdit_6;
    QLabel *label_31;
    QWidget *tab5;
    QDateEdit *dateEdit;
    QDateEdit *dateEdit_2;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QPushButton *pushButton_14;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1163, 643);
        MainWindow->setBaseSize(QSize(15, 15));
        MainWindow->setIconSize(QSize(50, 50));
        MainWindow->setAnimated(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        home = new QTabWidget(centralwidget);
        home->setObjectName(QStringLiteral("home"));
        home->setGeometry(QRect(20, 40, 1091, 581));
        home->setMinimumSize(QSize(0, 399));
        home->setStyleSheet(QLatin1String("selection-background-color: rgb(170, 0, 0);\n"
"font: 75 16pt \"MS Shell Dlg 2\";"));
        home->setTabPosition(QTabWidget::North);
        home->setTabShape(QTabWidget::Triangular);
        home->setIconSize(QSize(20, 20));
        home->setElideMode(Qt::ElideMiddle);
        home->setUsesScrollButtons(true);
        home->setDocumentMode(false);
        home->setTabBarAutoHide(false);
        tab0 = new QWidget();
        tab0->setObjectName(QStringLiteral("tab0"));
        tab0->setBaseSize(QSize(0, 1));
        QFont font;
        font.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font.setPointSize(16);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(9);
        tab0->setFont(font);
        dateTimeEdit = new QDateTimeEdit(tab0);
        dateTimeEdit->setObjectName(QStringLiteral("dateTimeEdit"));
        dateTimeEdit->setGeometry(QRect(830, 40, 221, 51));
        pushButton_19 = new QPushButton(tab0);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setGeometry(QRect(420, 220, 211, 51));
        pushButton_20 = new QPushButton(tab0);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setGeometry(QRect(820, 410, 211, 51));
        home->addTab(tab0, QString());
        tab1 = new QWidget();
        tab1->setObjectName(QStringLiteral("tab1"));
        tableWidget = new QTableWidget(tab1);
        if (tableWidget->columnCount() < 6)
            tableWidget->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        if (tableWidget->rowCount() < 5)
            tableWidget->setRowCount(5);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setGeometry(QRect(80, 270, 871, 231));
        tableWidget->setFrameShape(QFrame::StyledPanel);
        tableWidget->setFrameShadow(QFrame::Plain);
        tableWidget->setLineWidth(0);
        tableWidget->setMidLineWidth(0);
        tableWidget->setShowGrid(true);
        tableWidget->setSortingEnabled(true);
        tableWidget->setRowCount(5);
        tableWidget->setColumnCount(6);
        tableWidget->horizontalHeader()->setDefaultSectionSize(140);
        pushButton_2 = new QPushButton(tab1);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(720, 40, 201, 41));
        lineEdit_3 = new QLineEdit(tab1);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(160, 50, 331, 21));
        pushButton_3 = new QPushButton(tab1);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(720, 100, 201, 41));
        pushButton_4 = new QPushButton(tab1);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(720, 160, 201, 41));
        lineEdit_4 = new QLineEdit(tab1);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(160, 90, 331, 21));
        line = new QFrame(tab1);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(550, 30, 20, 171));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        lineEdit_5 = new QLineEdit(tab1);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(160, 130, 331, 21));
        label_4 = new QLabel(tab1);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 40, 81, 31));
        label_5 = new QLabel(tab1);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(30, 130, 91, 21));
        label_6 = new QLabel(tab1);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(50, 90, 61, 21));
        pushButton_5 = new QPushButton(tab1);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(280, 180, 211, 51));
        home->addTab(tab1, QString());
        tab2 = new QWidget();
        tab2->setObjectName(QStringLiteral("tab2"));
        label_10 = new QLabel(tab2);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(70, 100, 61, 21));
        line_2 = new QFrame(tab2);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setGeometry(QRect(570, 40, 20, 171));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        lineEdit_6 = new QLineEdit(tab2);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(180, 60, 331, 21));
        label_11 = new QLabel(tab2);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(60, 50, 81, 31));
        lineEdit_7 = new QLineEdit(tab2);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(180, 140, 331, 21));
        lineEdit_8 = new QLineEdit(tab2);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(180, 100, 331, 21));
        label_12 = new QLabel(tab2);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(70, 140, 71, 21));
        tableWidget_2 = new QTableWidget(tab2);
        if (tableWidget_2->columnCount() < 6)
            tableWidget_2->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(2, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(3, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(4, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(5, __qtablewidgetitem11);
        if (tableWidget_2->rowCount() < 5)
            tableWidget_2->setRowCount(5);
        tableWidget_2->setObjectName(QStringLiteral("tableWidget_2"));
        tableWidget_2->setGeometry(QRect(120, 290, 871, 211));
        tableWidget_2->setFrameShape(QFrame::StyledPanel);
        tableWidget_2->setFrameShadow(QFrame::Plain);
        tableWidget_2->setLineWidth(0);
        tableWidget_2->setMidLineWidth(0);
        tableWidget_2->setShowGrid(true);
        tableWidget_2->setSortingEnabled(true);
        tableWidget_2->setRowCount(5);
        tableWidget_2->setColumnCount(6);
        tableWidget_2->horizontalHeader()->setDefaultSectionSize(140);
        pushButton_9 = new QPushButton(tab2);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(730, 170, 201, 41));
        pushButton_6 = new QPushButton(tab2);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(290, 190, 211, 51));
        pushButton_8 = new QPushButton(tab2);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(730, 50, 201, 41));
        pushButton_7 = new QPushButton(tab2);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(730, 110, 201, 41));
        home->addTab(tab2, QString());
        tab3 = new QWidget();
        tab3->setObjectName(QStringLiteral("tab3"));
        tableWidget_4 = new QTableWidget(tab3);
        if (tableWidget_4->columnCount() < 6)
            tableWidget_4->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(0, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(1, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(2, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(3, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(4, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(5, __qtablewidgetitem17);
        if (tableWidget_4->rowCount() < 5)
            tableWidget_4->setRowCount(5);
        tableWidget_4->setObjectName(QStringLiteral("tableWidget_4"));
        tableWidget_4->setGeometry(QRect(100, 270, 871, 231));
        tableWidget_4->setFrameShape(QFrame::StyledPanel);
        tableWidget_4->setFrameShadow(QFrame::Plain);
        tableWidget_4->setLineWidth(0);
        tableWidget_4->setMidLineWidth(0);
        tableWidget_4->setShowGrid(true);
        tableWidget_4->setSortingEnabled(true);
        tableWidget_4->setRowCount(5);
        tableWidget_4->setColumnCount(6);
        tableWidget_4->horizontalHeader()->setDefaultSectionSize(140);
        pushButton_15 = new QPushButton(tab3);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(780, 180, 201, 41));
        pushButton_16 = new QPushButton(tab3);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(280, 190, 211, 51));
        label_13 = new QLabel(tab3);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(110, 110, 61, 21));
        label_14 = new QLabel(tab3);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(100, 60, 81, 31));
        lineEdit_9 = new QLineEdit(tab3);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(220, 70, 331, 21));
        lineEdit_10 = new QLineEdit(tab3);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(220, 110, 331, 21));
        line_4 = new QFrame(tab3);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setGeometry(QRect(610, 50, 20, 171));
        line_4->setFrameShape(QFrame::VLine);
        line_4->setFrameShadow(QFrame::Sunken);
        pushButton_17 = new QPushButton(tab3);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(780, 60, 201, 41));
        pushButton_18 = new QPushButton(tab3);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setGeometry(QRect(780, 120, 201, 41));
        lineEdit_11 = new QLineEdit(tab3);
        lineEdit_11->setObjectName(QStringLiteral("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(220, 150, 331, 21));
        label_15 = new QLabel(tab3);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(90, 150, 91, 21));
        home->addTab(tab3, QString());
        tab4 = new QWidget();
        tab4->setObjectName(QStringLiteral("tab4"));
        pushButton_10 = new QPushButton(tab4);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(830, 100, 201, 31));
        pushButton_11 = new QPushButton(tab4);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(240, 190, 251, 41));
        line_3 = new QFrame(tab4);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setGeometry(QRect(690, 30, 20, 171));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        pushButton_12 = new QPushButton(tab4);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(830, 150, 201, 31));
        tableWidget_3 = new QTableWidget(tab4);
        if (tableWidget_3->columnCount() < 7)
            tableWidget_3->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(0, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(1, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(2, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(3, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(4, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(5, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(6, __qtablewidgetitem24);
        if (tableWidget_3->rowCount() < 5)
            tableWidget_3->setRowCount(5);
        QFont font1;
        font1.setPointSize(6);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        __qtablewidgetitem25->setFont(font1);
        tableWidget_3->setItem(0, 0, __qtablewidgetitem25);
        tableWidget_3->setObjectName(QStringLiteral("tableWidget_3"));
        tableWidget_3->setGeometry(QRect(10, 280, 1051, 221));
        tableWidget_3->setFont(font);
        tableWidget_3->setFrameShape(QFrame::StyledPanel);
        tableWidget_3->setFrameShadow(QFrame::Plain);
        tableWidget_3->setLineWidth(0);
        tableWidget_3->setMidLineWidth(0);
        tableWidget_3->setShowGrid(true);
        tableWidget_3->setSortingEnabled(true);
        tableWidget_3->setRowCount(5);
        tableWidget_3->setColumnCount(7);
        tableWidget_3->horizontalHeader()->setDefaultSectionSize(145);
        tableWidget_3->horizontalHeader()->setMinimumSectionSize(33);
        tableWidget_3->verticalHeader()->setDefaultSectionSize(33);
        pushButton_13 = new QPushButton(tab4);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(830, 50, 201, 31));
        dateEdit_5 = new QDateEdit(tab4);
        dateEdit_5->setObjectName(QStringLiteral("dateEdit_5"));
        dateEdit_5->setGeometry(QRect(450, 80, 161, 31));
        label_30 = new QLabel(tab4);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setGeometry(QRect(370, 80, 81, 31));
        dateEdit_6 = new QDateEdit(tab4);
        dateEdit_6->setObjectName(QStringLiteral("dateEdit_6"));
        dateEdit_6->setGeometry(QRect(190, 80, 161, 31));
        label_31 = new QLabel(tab4);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(50, 80, 81, 31));
        home->addTab(tab4, QString());
        tab5 = new QWidget();
        tab5->setObjectName(QStringLiteral("tab5"));
        dateEdit = new QDateEdit(tab5);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(450, 60, 161, 31));
        dateEdit_2 = new QDateEdit(tab5);
        dateEdit_2->setObjectName(QStringLiteral("dateEdit_2"));
        dateEdit_2->setGeometry(QRect(160, 60, 161, 31));
        label_7 = new QLabel(tab5);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(60, 60, 81, 31));
        label_8 = new QLabel(tab5);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(370, 60, 81, 31));
        label_9 = new QLabel(tab5);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(160, 160, 711, 341));
        label_9->setPixmap(QPixmap(QString::fromUtf8("../gr\303\241fico.png")));
        pushButton_14 = new QPushButton(tab5);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(660, 50, 251, 41));
        home->addTab(tab5, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1163, 30));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        home->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
#ifndef QT_NO_WHATSTHIS
        home->setWhatsThis(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><br/></p></body></html>", Q_NULLPTR));
#endif // QT_NO_WHATSTHIS
        pushButton_19->setText(QApplication::translate("MainWindow", "Nuevo Pedido", Q_NULLPTR));
        pushButton_20->setText(QApplication::translate("MainWindow", "Salir", Q_NULLPTR));
        home->setTabText(home->indexOf(tab0), QApplication::translate("MainWindow", "Home", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("MainWindow", "Id", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("MainWindow", "Apellidos ", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("MainWindow", "Dni", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("MainWindow", "Tlf", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("MainWindow", "Email", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Telefono ", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "Dni", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        home->setTabText(home->indexOf(tab1), QApplication::translate("MainWindow", "Clientes", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "CIF", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        label_12->setText(QApplication::translate("MainWindow", "Tlf", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_2->horizontalHeaderItem(0);
        ___qtablewidgetitem6->setText(QApplication::translate("MainWindow", "Id", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_2->horizontalHeaderItem(1);
        ___qtablewidgetitem7->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_2->horizontalHeaderItem(2);
        ___qtablewidgetitem8->setText(QApplication::translate("MainWindow", "Apellidos ", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget_2->horizontalHeaderItem(3);
        ___qtablewidgetitem9->setText(QApplication::translate("MainWindow", "CIF", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget_2->horizontalHeaderItem(4);
        ___qtablewidgetitem10->setText(QApplication::translate("MainWindow", "Tlf", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget_2->horizontalHeaderItem(5);
        ___qtablewidgetitem11->setText(QApplication::translate("MainWindow", "Email", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        home->setTabText(home->indexOf(tab2), QApplication::translate("MainWindow", "Proveedores", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_4->horizontalHeaderItem(0);
        ___qtablewidgetitem12->setText(QApplication::translate("MainWindow", "Id", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_4->horizontalHeaderItem(1);
        ___qtablewidgetitem13->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_4->horizontalHeaderItem(2);
        ___qtablewidgetitem14->setText(QApplication::translate("MainWindow", "Apellidos ", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_4->horizontalHeaderItem(3);
        ___qtablewidgetitem15->setText(QApplication::translate("MainWindow", "Dni", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget_4->horizontalHeaderItem(4);
        ___qtablewidgetitem16->setText(QApplication::translate("MainWindow", "Tlf", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget_4->horizontalHeaderItem(5);
        ___qtablewidgetitem17->setText(QApplication::translate("MainWindow", "Email", Q_NULLPTR));
        pushButton_15->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        pushButton_16->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "Dni", Q_NULLPTR));
        label_14->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        pushButton_17->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        pushButton_18->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "Telefono ", Q_NULLPTR));
        home->setTabText(home->indexOf(tab3), QApplication::translate("MainWindow", "Productos", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget_3->horizontalHeaderItem(0);
        ___qtablewidgetitem18->setText(QApplication::translate("MainWindow", "Producto ", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget_3->horizontalHeaderItem(1);
        ___qtablewidgetitem19->setText(QApplication::translate("MainWindow", "Descripcion", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget_3->horizontalHeaderItem(2);
        ___qtablewidgetitem20->setText(QApplication::translate("MainWindow", "Fecha", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget_3->horizontalHeaderItem(3);
        ___qtablewidgetitem21->setText(QApplication::translate("MainWindow", "Cantidad", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidget_3->horizontalHeaderItem(4);
        ___qtablewidgetitem22->setText(QApplication::translate("MainWindow", "PrecioPorUnidad", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidget_3->horizontalHeaderItem(5);
        ___qtablewidgetitem23->setText(QApplication::translate("MainWindow", "FechaEnvio", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidget_3->horizontalHeaderItem(6);
        ___qtablewidgetitem24->setText(QApplication::translate("MainWindow", "Total", Q_NULLPTR));

        const bool __sortingEnabled = tableWidget_3->isSortingEnabled();
        tableWidget_3->setSortingEnabled(false);
        tableWidget_3->setSortingEnabled(__sortingEnabled);

        pushButton_13->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        label_30->setText(QApplication::translate("MainWindow", "Hasta", Q_NULLPTR));
        label_31->setText(QApplication::translate("MainWindow", "Desde", Q_NULLPTR));
        home->setTabText(home->indexOf(tab4), QApplication::translate("MainWindow", "Pedidos", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Desde", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Hasta", Q_NULLPTR));
        label_9->setText(QString());
        pushButton_14->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        home->setTabText(home->indexOf(tab5), QApplication::translate("MainWindow", "Ventas", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INICIAR_H
