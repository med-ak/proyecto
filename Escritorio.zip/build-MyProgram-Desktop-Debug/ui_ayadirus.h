/********************************************************************************
** Form generated from reading UI file 'ayadirus.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AYADIRUS_H
#define UI_AYADIRUS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_ayadirus
{
public:
    QGridLayout *gridLayout;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton;
    QLabel *label_6;
    QLineEdit *lineEdit_4;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_4;
    QLineEdit *lineEdit_5;
    QPushButton *pushButton_2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_7;
    QLineEdit *lineEdit_6;
    QPushButton *pushButton_3;
    QSpacerItem *verticalSpacer;
    QLabel *label_5;

    void setupUi(QDialog *ayadirus)
    {
        if (ayadirus->objectName().isEmpty())
            ayadirus->setObjectName(QStringLiteral("ayadirus"));
        ayadirus->resize(561, 305);
        gridLayout = new QGridLayout(ayadirus);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalSpacer_2 = new QSpacerItem(20, 19, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 0, 1, 1, 1);

        label_4 = new QLabel(ayadirus);
        label_4->setObjectName(QStringLiteral("label_4"));
        QFont font;
        font.setPointSize(12);
        label_4->setFont(font);
        label_4->setLayoutDirection(Qt::LeftToRight);
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_4, 1, 0, 1, 1);

        lineEdit_3 = new QLineEdit(ayadirus);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setFont(font);

        gridLayout->addWidget(lineEdit_3, 1, 1, 1, 1);

        pushButton = new QPushButton(ayadirus);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setMinimumSize(QSize(200, 50));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        pushButton->setFont(font1);

        gridLayout->addWidget(pushButton, 1, 3, 2, 1);

        label_6 = new QLabel(ayadirus);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setFont(font);
        label_6->setLayoutDirection(Qt::LeftToRight);
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_6, 2, 0, 2, 1);

        lineEdit_4 = new QLineEdit(ayadirus);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setFont(font);

        gridLayout->addWidget(lineEdit_4, 2, 1, 2, 1);

        horizontalSpacer = new QSpacerItem(14, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 3, 2, 1, 1);

        pushButton_4 = new QPushButton(ayadirus);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(200, 50));
        pushButton_4->setFont(font1);

        gridLayout->addWidget(pushButton_4, 3, 3, 2, 1);

        lineEdit_5 = new QLineEdit(ayadirus);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setFont(font);

        gridLayout->addWidget(lineEdit_5, 4, 1, 2, 1);

        pushButton_2 = new QPushButton(ayadirus);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(200, 50));
        pushButton_2->setFont(font1);

        gridLayout->addWidget(pushButton_2, 5, 3, 2, 1);

        horizontalSpacer_2 = new QSpacerItem(14, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 5, 4, 1, 1);

        label_7 = new QLabel(ayadirus);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font);
        label_7->setLayoutDirection(Qt::LeftToRight);
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_7, 6, 0, 1, 1);

        lineEdit_6 = new QLineEdit(ayadirus);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setFont(font);

        gridLayout->addWidget(lineEdit_6, 6, 1, 1, 1);

        pushButton_3 = new QPushButton(ayadirus);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(200, 50));
        pushButton_3->setFont(font1);

        gridLayout->addWidget(pushButton_3, 7, 3, 1, 1);

        verticalSpacer = new QSpacerItem(20, 19, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 8, 1, 1, 1);

        label_5 = new QLabel(ayadirus);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font);
        label_5->setLayoutDirection(Qt::LeftToRight);
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_5, 4, 0, 2, 1);


        retranslateUi(ayadirus);

        QMetaObject::connectSlotsByName(ayadirus);
    } // setupUi

    void retranslateUi(QDialog *ayadirus)
    {
        ayadirus->setWindowTitle(QApplication::translate("ayadirus", "Dialog", Q_NULLPTR));
        label_4->setText(QApplication::translate("ayadirus", "Nombre", Q_NULLPTR));
        pushButton->setText(QApplication::translate("ayadirus", "Guardar", Q_NULLPTR));
        label_6->setText(QApplication::translate("ayadirus", "Apellidos", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("ayadirus", "Modificar", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("ayadirus", "Borrar ", Q_NULLPTR));
        label_7->setText(QApplication::translate("ayadirus", "Contrase\303\261a", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("ayadirus", "Salir", Q_NULLPTR));
        label_5->setText(QApplication::translate("ayadirus", "    NombreUsuario", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ayadirus: public Ui_ayadirus {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AYADIRUS_H
