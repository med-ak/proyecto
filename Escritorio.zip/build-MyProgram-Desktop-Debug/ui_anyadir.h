/********************************************************************************
** Form generated from reading UI file 'anyadir.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ANYADIR_H
#define UI_ANYADIR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_anyadir
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_6;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QLineEdit *lineEdit_3;
    QLabel *label_7;
    QLineEdit *lineEdit_4;
    QPushButton *pushButton_3;
    QLineEdit *lineEdit_5;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_7;
    QLabel *label_5;
    QPushButton *pushButton_4;
    QLabel *label_8;
    QLabel *label_6;
    QLabel *label_4;
    QSpacerItem *verticalSpacer_2;

    void setupUi(QDialog *anyadir)
    {
        if (anyadir->objectName().isEmpty())
            anyadir->setObjectName(QStringLiteral("anyadir"));
        anyadir->resize(603, 264);
        gridLayout = new QGridLayout(anyadir);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        lineEdit_6 = new QLineEdit(anyadir);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        QFont font;
        font.setPointSize(12);
        lineEdit_6->setFont(font);

        gridLayout->addWidget(lineEdit_6, 6, 2, 1, 1);

        pushButton = new QPushButton(anyadir);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setMinimumSize(QSize(200, 50));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        pushButton->setFont(font1);

        gridLayout->addWidget(pushButton, 1, 4, 2, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 5, 5, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 2, 3, 2, 1);

        lineEdit_3 = new QLineEdit(anyadir);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setFont(font);

        gridLayout->addWidget(lineEdit_3, 1, 2, 1, 1);

        label_7 = new QLabel(anyadir);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font);
        label_7->setLayoutDirection(Qt::LeftToRight);
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_7, 6, 1, 1, 1);

        lineEdit_4 = new QLineEdit(anyadir);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setFont(font);

        gridLayout->addWidget(lineEdit_4, 2, 2, 2, 1);

        pushButton_3 = new QPushButton(anyadir);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(200, 50));
        pushButton_3->setFont(font1);

        gridLayout->addWidget(pushButton_3, 7, 4, 1, 1);

        lineEdit_5 = new QLineEdit(anyadir);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setFont(font);

        gridLayout->addWidget(lineEdit_5, 4, 2, 2, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 4, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 8, 2, 1, 1);

        pushButton_2 = new QPushButton(anyadir);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(200, 50));
        pushButton_2->setFont(font1);

        gridLayout->addWidget(pushButton_2, 5, 4, 2, 1);

        lineEdit_7 = new QLineEdit(anyadir);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setFont(font);

        gridLayout->addWidget(lineEdit_7, 7, 2, 1, 1);

        label_5 = new QLabel(anyadir);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font);
        label_5->setLayoutDirection(Qt::LeftToRight);
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_5, 4, 1, 2, 1);

        pushButton_4 = new QPushButton(anyadir);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(200, 50));
        pushButton_4->setFont(font1);

        gridLayout->addWidget(pushButton_4, 3, 4, 2, 1);

        label_8 = new QLabel(anyadir);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setFont(font);
        label_8->setLayoutDirection(Qt::LeftToRight);
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_8, 7, 1, 1, 1);

        label_6 = new QLabel(anyadir);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setFont(font);
        label_6->setLayoutDirection(Qt::LeftToRight);
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_6, 2, 1, 2, 1);

        label_4 = new QLabel(anyadir);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setFont(font);
        label_4->setLayoutDirection(Qt::LeftToRight);
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_4, 1, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 0, 2, 1, 1);


        retranslateUi(anyadir);

        QMetaObject::connectSlotsByName(anyadir);
    } // setupUi

    void retranslateUi(QDialog *anyadir)
    {
        anyadir->setWindowTitle(QApplication::translate("anyadir", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("anyadir", "Guardar", Q_NULLPTR));
        label_7->setText(QApplication::translate("anyadir", "Telefono ", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("anyadir", "Salir", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("anyadir", "Borrar ", Q_NULLPTR));
        label_5->setText(QApplication::translate("anyadir", "Dni", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("anyadir", "Modificar", Q_NULLPTR));
        label_8->setText(QApplication::translate("anyadir", "Email", Q_NULLPTR));
        label_6->setText(QApplication::translate("anyadir", "Apellidos", Q_NULLPTR));
        label_4->setText(QApplication::translate("anyadir", "Nombre", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class anyadir: public Ui_anyadir {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ANYADIR_H
