/********************************************************************************
** Form generated from reading UI file 'pedidos.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PEDIDOS_H
#define UI_PEDIDOS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_pedidos
{
public:
    QGridLayout *gridLayout;
    QPushButton *pushButton_58;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_2;
    QTableWidget *tableWidget_4;
    QLabel *label_13;
    QLineEdit *lineEdit_10;
    QPushButton *pushButton;
    QPushButton *pushButton_57;
    QLabel *label;
    QLabel *label_46;
    QLineEdit *lineEdit_33;
    QTableWidget *tableWidget_5;
    QSpacerItem *verticalSpacer;

    void setupUi(QDialog *pedidos)
    {
        if (pedidos->objectName().isEmpty())
            pedidos->setObjectName(QStringLiteral("pedidos"));
        pedidos->resize(1058, 612);
        pedidos->setMinimumSize(QSize(0, 0));
        pedidos->setSizeGripEnabled(true);
        gridLayout = new QGridLayout(pedidos);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        pushButton_58 = new QPushButton(pedidos);
        pushButton_58->setObjectName(QStringLiteral("pushButton_58"));
        QFont font;
        font.setPointSize(12);
        pushButton_58->setFont(font);

        gridLayout->addWidget(pushButton_58, 3, 4, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 3, 1, 1);

        pushButton_2 = new QPushButton(pedidos);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(200, 50));
        pushButton_2->setFont(font);

        gridLayout->addWidget(pushButton_2, 7, 4, 1, 1);

        tableWidget_4 = new QTableWidget(pedidos);
        if (tableWidget_4->columnCount() < 6)
            tableWidget_4->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        if (tableWidget_4->rowCount() < 5)
            tableWidget_4->setRowCount(5);
        tableWidget_4->setObjectName(QStringLiteral("tableWidget_4"));
        tableWidget_4->setFrameShape(QFrame::StyledPanel);
        tableWidget_4->setFrameShadow(QFrame::Plain);
        tableWidget_4->setLineWidth(0);
        tableWidget_4->setMidLineWidth(0);
        tableWidget_4->setShowGrid(true);
        tableWidget_4->setSortingEnabled(true);
        tableWidget_4->setRowCount(5);
        tableWidget_4->setColumnCount(6);
        tableWidget_4->horizontalHeader()->setDefaultSectionSize(170);

        gridLayout->addWidget(tableWidget_4, 4, 0, 1, 6);

        label_13 = new QLabel(pedidos);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setFont(font);

        gridLayout->addWidget(label_13, 1, 0, 1, 2);

        lineEdit_10 = new QLineEdit(pedidos);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));

        gridLayout->addWidget(lineEdit_10, 1, 2, 1, 1);

        pushButton = new QPushButton(pedidos);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setMinimumSize(QSize(200, 50));
        pushButton->setFont(font);

        gridLayout->addWidget(pushButton, 7, 5, 1, 1);

        pushButton_57 = new QPushButton(pedidos);
        pushButton_57->setObjectName(QStringLiteral("pushButton_57"));
        pushButton_57->setFont(font);

        gridLayout->addWidget(pushButton_57, 2, 1, 1, 2);

        label = new QLabel(pedidos);
        label->setObjectName(QStringLiteral("label"));
        QFont font1;
        font1.setPointSize(18);
        font1.setBold(false);
        font1.setWeight(50);
        label->setFont(font1);

        gridLayout->addWidget(label, 6, 5, 1, 1);

        label_46 = new QLabel(pedidos);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setFont(font);

        gridLayout->addWidget(label_46, 0, 0, 1, 1);

        lineEdit_33 = new QLineEdit(pedidos);
        lineEdit_33->setObjectName(QStringLiteral("lineEdit_33"));

        gridLayout->addWidget(lineEdit_33, 0, 2, 1, 1);

        tableWidget_5 = new QTableWidget(pedidos);
        if (tableWidget_5->columnCount() < 3)
            tableWidget_5->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(2, __qtablewidgetitem8);
        if (tableWidget_5->rowCount() < 5)
            tableWidget_5->setRowCount(5);
        tableWidget_5->setObjectName(QStringLiteral("tableWidget_5"));
        tableWidget_5->setMinimumSize(QSize(550, 200));
        tableWidget_5->setFrameShape(QFrame::StyledPanel);
        tableWidget_5->setFrameShadow(QFrame::Plain);
        tableWidget_5->setLineWidth(0);
        tableWidget_5->setMidLineWidth(0);
        tableWidget_5->setShowGrid(true);
        tableWidget_5->setSortingEnabled(true);
        tableWidget_5->setRowCount(5);
        tableWidget_5->setColumnCount(3);
        tableWidget_5->horizontalHeader()->setDefaultSectionSize(170);

        gridLayout->addWidget(tableWidget_5, 0, 4, 3, 2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 5, 5, 1, 1);


        retranslateUi(pedidos);

        QMetaObject::connectSlotsByName(pedidos);
    } // setupUi

    void retranslateUi(QDialog *pedidos)
    {
        pedidos->setWindowTitle(QApplication::translate("pedidos", "Dialog", Q_NULLPTR));
        pushButton_58->setText(QApplication::translate("pedidos", "A\303\261adir", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("pedidos", "Guardar", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_4->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("pedidos", "Codigo de barras", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_4->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("pedidos", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_4->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("pedidos", "Descripci\303\263n", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget_4->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("pedidos", "PrecioPorUnidad", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget_4->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("pedidos", "Fecha", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget_4->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("pedidos", "Total", Q_NULLPTR));
        label_13->setText(QApplication::translate("pedidos", "Codigo de barras", Q_NULLPTR));
        pushButton->setText(QApplication::translate("pedidos", "Salir", Q_NULLPTR));
        pushButton_57->setText(QApplication::translate("pedidos", "Buscar", Q_NULLPTR));
        label->setText(QApplication::translate("pedidos", "Total : 0", Q_NULLPTR));
        label_46->setText(QApplication::translate("pedidos", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_5->horizontalHeaderItem(0);
        ___qtablewidgetitem6->setText(QApplication::translate("pedidos", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_5->horizontalHeaderItem(1);
        ___qtablewidgetitem7->setText(QApplication::translate("pedidos", "Descripci\303\263n", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_5->horizontalHeaderItem(2);
        ___qtablewidgetitem8->setText(QApplication::translate("pedidos", "PrecioPorUnidad", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class pedidos: public Ui_pedidos {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PEDIDOS_H
