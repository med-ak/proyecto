/********************************************************************************
** Form generated from reading UI file 'anyadirusuarios.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ANYADIRUSUARIOS_H
#define UI_ANYADIRUSUARIOS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_anyadirUsuarios
{
public:
    QGridLayout *gridLayout;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton;
    QLabel *label_6;
    QLineEdit *lineEdit_4;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_4;
    QSpacerItem *horizontalSpacer_3;
    QLabel *label_5;
    QLineEdit *lineEdit_5;
    QPushButton *pushButton_2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_7;
    QLineEdit *lineEdit_6;
    QPushButton *pushButton_3;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *anyadirUsuarios)
    {
        if (anyadirUsuarios->objectName().isEmpty())
            anyadirUsuarios->setObjectName(QStringLiteral("anyadirUsuarios"));
        anyadirUsuarios->resize(627, 287);
        gridLayout = new QGridLayout(anyadirUsuarios);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalSpacer_2 = new QSpacerItem(20, 7, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 0, 2, 1, 1);

        label_4 = new QLabel(anyadirUsuarios);
        label_4->setObjectName(QStringLiteral("label_4"));
        QFont font;
        font.setPointSize(12);
        label_4->setFont(font);
        label_4->setLayoutDirection(Qt::LeftToRight);
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_4, 1, 1, 1, 1);

        lineEdit_3 = new QLineEdit(anyadirUsuarios);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setFont(font);

        gridLayout->addWidget(lineEdit_3, 1, 2, 1, 1);

        pushButton = new QPushButton(anyadirUsuarios);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setMinimumSize(QSize(200, 50));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        pushButton->setFont(font1);

        gridLayout->addWidget(pushButton, 1, 4, 2, 1);

        label_6 = new QLabel(anyadirUsuarios);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setFont(font);
        label_6->setLayoutDirection(Qt::LeftToRight);
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_6, 2, 1, 2, 1);

        lineEdit_4 = new QLineEdit(anyadirUsuarios);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setFont(font);

        gridLayout->addWidget(lineEdit_4, 2, 2, 2, 1);

        horizontalSpacer = new QSpacerItem(36, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 2, 3, 2, 1);

        pushButton_4 = new QPushButton(anyadirUsuarios);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(200, 50));
        pushButton_4->setFont(font1);

        gridLayout->addWidget(pushButton_4, 3, 4, 2, 1);

        horizontalSpacer_3 = new QSpacerItem(36, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 4, 0, 1, 1);

        label_5 = new QLabel(anyadirUsuarios);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font);
        label_5->setLayoutDirection(Qt::LeftToRight);
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_5, 4, 1, 2, 1);

        lineEdit_5 = new QLineEdit(anyadirUsuarios);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setFont(font);

        gridLayout->addWidget(lineEdit_5, 4, 2, 2, 1);

        pushButton_2 = new QPushButton(anyadirUsuarios);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(200, 50));
        pushButton_2->setFont(font1);

        gridLayout->addWidget(pushButton_2, 5, 4, 2, 1);

        horizontalSpacer_2 = new QSpacerItem(36, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 5, 5, 1, 1);

        label_7 = new QLabel(anyadirUsuarios);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font);
        label_7->setLayoutDirection(Qt::LeftToRight);
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_7, 6, 1, 1, 1);

        lineEdit_6 = new QLineEdit(anyadirUsuarios);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setFont(font);

        gridLayout->addWidget(lineEdit_6, 6, 2, 1, 1);

        pushButton_3 = new QPushButton(anyadirUsuarios);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(200, 50));
        pushButton_3->setFont(font1);

        gridLayout->addWidget(pushButton_3, 7, 4, 1, 1);

        verticalSpacer = new QSpacerItem(20, 7, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 8, 2, 1, 1);


        retranslateUi(anyadirUsuarios);

        QMetaObject::connectSlotsByName(anyadirUsuarios);
    } // setupUi

    void retranslateUi(QWidget *anyadirUsuarios)
    {
        anyadirUsuarios->setWindowTitle(QApplication::translate("anyadirUsuarios", "Form", Q_NULLPTR));
        label_4->setText(QApplication::translate("anyadirUsuarios", "Nombre", Q_NULLPTR));
        pushButton->setText(QApplication::translate("anyadirUsuarios", "Guardar", Q_NULLPTR));
        label_6->setText(QApplication::translate("anyadirUsuarios", "Apellidos", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("anyadirUsuarios", "Modificar", Q_NULLPTR));
        label_5->setText(QApplication::translate("anyadirUsuarios", "NombreUsuario", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("anyadirUsuarios", "Borrar ", Q_NULLPTR));
        label_7->setText(QApplication::translate("anyadirUsuarios", "Contrase\303\261a", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("anyadirUsuarios", "Salir", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class anyadirUsuarios: public Ui_anyadirUsuarios {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ANYADIRUSUARIOS_H
