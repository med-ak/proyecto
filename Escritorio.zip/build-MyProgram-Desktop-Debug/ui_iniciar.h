/********************************************************************************
** Form generated from reading UI file 'iniciar.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INICIAR_H
#define UI_INICIAR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_Iniciar
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_13;
    QComboBox *comboBox_2;
    QPushButton *pushButton_20;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_17;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *lineEdit_12;
    QPushButton *pushButton_19;
    QLabel *label_20;

    void setupUi(QDialog *Iniciar)
    {
        if (Iniciar->objectName().isEmpty())
            Iniciar->setObjectName(QStringLiteral("Iniciar"));
        Iniciar->resize(647, 439);
        gridLayout = new QGridLayout(Iniciar);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        lineEdit_13 = new QLineEdit(Iniciar);
        lineEdit_13->setObjectName(QStringLiteral("lineEdit_13"));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        lineEdit_13->setFont(font);

        gridLayout->addWidget(lineEdit_13, 4, 2, 1, 2);

        comboBox_2 = new QComboBox(Iniciar);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        QFont font1;
        font1.setPointSize(16);
        font1.setBold(false);
        font1.setWeight(50);
        comboBox_2->setFont(font1);

        gridLayout->addWidget(comboBox_2, 3, 2, 1, 2);

        pushButton_20 = new QPushButton(Iniciar);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setMinimumSize(QSize(150, 60));
        QFont font2;
        font2.setPointSize(16);
        font2.setBold(true);
        font2.setWeight(75);
        pushButton_20->setFont(font2);

        gridLayout->addWidget(pushButton_20, 6, 3, 1, 1);

        label_18 = new QLabel(Iniciar);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setFont(font1);
        label_18->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_18, 5, 1, 1, 1);

        label_19 = new QLabel(Iniciar);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setFont(font1);
        label_19->setLayoutDirection(Qt::LeftToRight);
        label_19->setAutoFillBackground(false);
        label_19->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_19, 4, 1, 1, 1);

        label_17 = new QLabel(Iniciar);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setFont(font1);
        label_17->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_17, 3, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 1, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 6, 0, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 40, QSizePolicy::Maximum, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 6, 4, 1, 1);

        lineEdit_12 = new QLineEdit(Iniciar);
        lineEdit_12->setObjectName(QStringLiteral("lineEdit_12"));
        lineEdit_12->setFont(font);

        gridLayout->addWidget(lineEdit_12, 5, 2, 1, 2);

        pushButton_19 = new QPushButton(Iniciar);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setMinimumSize(QSize(150, 60));
        pushButton_19->setFont(font2);

        gridLayout->addWidget(pushButton_19, 6, 1, 1, 1);

        label_20 = new QLabel(Iniciar);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setMaximumSize(QSize(200, 50));
        QFont font3;
        font3.setPointSize(20);
        font3.setBold(false);
        font3.setWeight(50);
        label_20->setFont(font3);
        label_20->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_20, 2, 2, 1, 1);


        retranslateUi(Iniciar);

        QMetaObject::connectSlotsByName(Iniciar);
    } // setupUi

    void retranslateUi(QDialog *Iniciar)
    {
        Iniciar->setWindowTitle(QApplication::translate("Iniciar", "Dialog", Q_NULLPTR));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("Iniciar", "          Administrador", Q_NULLPTR)
         << QApplication::translate("Iniciar", "          Empleado", Q_NULLPTR)
        );
        pushButton_20->setText(QApplication::translate("Iniciar", "Salir", Q_NULLPTR));
        label_18->setText(QApplication::translate("Iniciar", "Contrase\303\261a", Q_NULLPTR));
        label_19->setText(QApplication::translate("Iniciar", "Usuario", Q_NULLPTR));
        label_17->setText(QApplication::translate("Iniciar", "Entrar como ", Q_NULLPTR));
        pushButton_19->setText(QApplication::translate("Iniciar", "Entrar", Q_NULLPTR));
        label_20->setText(QApplication::translate("Iniciar", "<html><head/><body><p><span style=\" font-weight:600;\">Iniciar sesi\303\263n</span></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Iniciar: public Ui_Iniciar {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INICIAR_H
