/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QTabWidget *home;
    QWidget *tab0;
    QHBoxLayout *horizontalLayout;
    QPushButton *btnNuevoPedido;
    QWidget *tab1;
    QGridLayout *gridLayout_8;
    QLabel *label_47;
    QLineEdit *lineEdit_35;
    QFrame *line_16;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *anyadir_6;
    QLabel *label_14;
    QLineEdit *lineEdit_34;
    QPushButton *pushButton_16;
    QLabel *label_48;
    QLineEdit *lineEdit_9;
    QSpacerItem *horizontalSpacer_12;
    QPushButton *pushButton_59;
    QPushButton *pushButton_60;
    QTableWidget *tableWidget_16;
    QWidget *tab2;
    QGridLayout *gridLayout_6;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *lineEdit_7;
    QFrame *line_2;
    QLabel *label_45;
    QPushButton *pushButton_55;
    QLineEdit *lineEdit_6;
    QTableWidget *tableWidget_2;
    QLabel *label_11;
    QLabel *label_10;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *pushButton_56;
    QPushButton *pushButton_7;
    QPushButton *anyadir_4;
    QLineEdit *lineEdit_8;
    QWidget *tab3;
    QGridLayout *gridLayout_7;
    QLabel *label_46;
    QLineEdit *lineEdit_33;
    QFrame *line_4;
    QSpacerItem *horizontalSpacer_11;
    QPushButton *anyadir_5;
    QLabel *label_13;
    QLineEdit *lineEdit_10;
    QPushButton *pushButton_15;
    QSpacerItem *horizontalSpacer_10;
    QPushButton *pushButton_57;
    QPushButton *pushButton_58;
    QTableWidget *tableWidget_4;
    QSpacerItem *verticalSpacer;
    QWidget *tab4;
    QGridLayout *gridLayout_12;
    QLabel *label_59;
    QPushButton *pushButton_72;
    QPushButton *anyadir_10;
    QTableWidget *tableWidget_3;
    QPushButton *pushButton_11;
    QLabel *label_61;
    QPushButton *pushButton_71;
    QFrame *line_20;
    QSpacerItem *horizontalSpacer_18;
    QSpacerItem *horizontalSpacer_19;
    QDateEdit *dateEdit_14;
    QDateEdit *dateEdit_13;
    QSpacerItem *verticalSpacer_3;
    QWidget *tab5;
    QGridLayout *gridLayout_2;
    QLabel *label_8;
    QFrame *frame;
    QPushButton *pushButton_17;
    QDateEdit *dateEdit;
    QPushButton *pushButton_14;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_7;
    QDateEdit *dateEdit_2;
    QWidget *tab;
    QGridLayout *gridLayout_13;
    QLabel *label_63;
    QLineEdit *lineEdit_47;
    QFrame *line_21;
    QSpacerItem *horizontalSpacer_21;
    QPushButton *anyadir_11;
    QLabel *label_15;
    QLineEdit *lineEdit_46;
    QPushButton *pushButton_19;
    QSpacerItem *horizontalSpacer_20;
    QPushButton *pushButton_74;
    QPushButton *pushButton_73;
    QTableWidget *tableWidget_5;
    QSpacerItem *verticalSpacer_4;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1086, 603);
        MainWindow->setBaseSize(QSize(15, 15));
        MainWindow->setIconSize(QSize(50, 50));
        MainWindow->setAnimated(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        home = new QTabWidget(centralwidget);
        home->setObjectName(QStringLiteral("home"));
        home->setMinimumSize(QSize(0, 0));
        home->setStyleSheet(QLatin1String("selection-background-color: rgb(170, 0, 0);\n"
"font: 75 16pt \"MS Shell Dlg 2\";"));
        home->setTabPosition(QTabWidget::North);
        home->setTabShape(QTabWidget::Triangular);
        home->setIconSize(QSize(20, 20));
        home->setElideMode(Qt::ElideMiddle);
        home->setUsesScrollButtons(true);
        home->setDocumentMode(false);
        home->setTabBarAutoHide(false);
        tab0 = new QWidget();
        tab0->setObjectName(QStringLiteral("tab0"));
        tab0->setBaseSize(QSize(0, 1));
        QFont font;
        font.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font.setPointSize(16);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(9);
        tab0->setFont(font);
        horizontalLayout = new QHBoxLayout(tab0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        btnNuevoPedido = new QPushButton(tab0);
        btnNuevoPedido->setObjectName(QStringLiteral("btnNuevoPedido"));
        btnNuevoPedido->setMinimumSize(QSize(300, 100));
        btnNuevoPedido->setMaximumSize(QSize(300, 16777215));
        btnNuevoPedido->setStyleSheet(QStringLiteral("font: 14pt \"Noto Sans\";"));
        QIcon icon;
        icon.addFile(QStringLiteral("Img/10122.png"), QSize(), QIcon::Normal, QIcon::Off);
        btnNuevoPedido->setIcon(icon);
        btnNuevoPedido->setIconSize(QSize(40, 40));
        btnNuevoPedido->setAutoRepeatDelay(400);
        btnNuevoPedido->setAutoRepeatInterval(200);

        horizontalLayout->addWidget(btnNuevoPedido);

        home->addTab(tab0, QString());
        tab1 = new QWidget();
        tab1->setObjectName(QStringLiteral("tab1"));
        gridLayout_8 = new QGridLayout(tab1);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        label_47 = new QLabel(tab1);
        label_47->setObjectName(QStringLiteral("label_47"));

        gridLayout_8->addWidget(label_47, 0, 0, 1, 1);

        lineEdit_35 = new QLineEdit(tab1);
        lineEdit_35->setObjectName(QStringLiteral("lineEdit_35"));

        gridLayout_8->addWidget(lineEdit_35, 0, 1, 1, 1);

        line_16 = new QFrame(tab1);
        line_16->setObjectName(QStringLiteral("line_16"));
        line_16->setFrameShape(QFrame::VLine);
        line_16->setFrameShadow(QFrame::Sunken);

        gridLayout_8->addWidget(line_16, 0, 2, 4, 1);

        horizontalSpacer_3 = new QSpacerItem(215, 13, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_8->addItem(horizontalSpacer_3, 0, 3, 1, 1);

        anyadir_6 = new QPushButton(tab1);
        anyadir_6->setObjectName(QStringLiteral("anyadir_6"));
        anyadir_6->setMinimumSize(QSize(200, 0));

        gridLayout_8->addWidget(anyadir_6, 0, 4, 1, 1);

        label_14 = new QLabel(tab1);
        label_14->setObjectName(QStringLiteral("label_14"));

        gridLayout_8->addWidget(label_14, 1, 0, 1, 1);

        lineEdit_34 = new QLineEdit(tab1);
        lineEdit_34->setObjectName(QStringLiteral("lineEdit_34"));

        gridLayout_8->addWidget(lineEdit_34, 1, 1, 1, 1);

        pushButton_16 = new QPushButton(tab1);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));

        gridLayout_8->addWidget(pushButton_16, 1, 4, 2, 1);

        label_48 = new QLabel(tab1);
        label_48->setObjectName(QStringLiteral("label_48"));

        gridLayout_8->addWidget(label_48, 2, 0, 1, 1);

        lineEdit_9 = new QLineEdit(tab1);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));

        gridLayout_8->addWidget(lineEdit_9, 2, 1, 1, 1);

        horizontalSpacer_12 = new QSpacerItem(215, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_8->addItem(horizontalSpacer_12, 3, 0, 1, 1);

        pushButton_59 = new QPushButton(tab1);
        pushButton_59->setObjectName(QStringLiteral("pushButton_59"));

        gridLayout_8->addWidget(pushButton_59, 3, 1, 1, 1);

        pushButton_60 = new QPushButton(tab1);
        pushButton_60->setObjectName(QStringLiteral("pushButton_60"));

        gridLayout_8->addWidget(pushButton_60, 3, 4, 1, 1);

        tableWidget_16 = new QTableWidget(tab1);
        if (tableWidget_16->columnCount() < 6)
            tableWidget_16->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_16->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_16->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_16->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget_16->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget_16->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget_16->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        if (tableWidget_16->rowCount() < 5)
            tableWidget_16->setRowCount(5);
        tableWidget_16->setObjectName(QStringLiteral("tableWidget_16"));
        tableWidget_16->setFrameShape(QFrame::StyledPanel);
        tableWidget_16->setFrameShadow(QFrame::Plain);
        tableWidget_16->setLineWidth(0);
        tableWidget_16->setMidLineWidth(0);
        tableWidget_16->setShowGrid(true);
        tableWidget_16->setSortingEnabled(true);
        tableWidget_16->setRowCount(5);
        tableWidget_16->setColumnCount(6);
        tableWidget_16->horizontalHeader()->setDefaultSectionSize(140);

        gridLayout_8->addWidget(tableWidget_16, 4, 0, 1, 5);

        home->addTab(tab1, QString());
        tab2 = new QWidget();
        tab2->setObjectName(QStringLiteral("tab2"));
        gridLayout_6 = new QGridLayout(tab2);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        horizontalSpacer_2 = new QSpacerItem(215, 13, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_6->addItem(horizontalSpacer_2, 0, 3, 1, 1);

        lineEdit_7 = new QLineEdit(tab2);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));

        gridLayout_6->addWidget(lineEdit_7, 1, 1, 1, 1);

        line_2 = new QFrame(tab2);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout_6->addWidget(line_2, 0, 2, 4, 1);

        label_45 = new QLabel(tab2);
        label_45->setObjectName(QStringLiteral("label_45"));

        gridLayout_6->addWidget(label_45, 0, 0, 1, 1);

        pushButton_55 = new QPushButton(tab2);
        pushButton_55->setObjectName(QStringLiteral("pushButton_55"));

        gridLayout_6->addWidget(pushButton_55, 3, 1, 1, 1);

        lineEdit_6 = new QLineEdit(tab2);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));

        gridLayout_6->addWidget(lineEdit_6, 2, 1, 1, 1);

        tableWidget_2 = new QTableWidget(tab2);
        if (tableWidget_2->columnCount() < 6)
            tableWidget_2->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(2, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(3, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(4, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(5, __qtablewidgetitem11);
        if (tableWidget_2->rowCount() < 5)
            tableWidget_2->setRowCount(5);
        tableWidget_2->setObjectName(QStringLiteral("tableWidget_2"));
        tableWidget_2->setFrameShape(QFrame::StyledPanel);
        tableWidget_2->setFrameShadow(QFrame::Plain);
        tableWidget_2->setLineWidth(0);
        tableWidget_2->setMidLineWidth(0);
        tableWidget_2->setShowGrid(true);
        tableWidget_2->setSortingEnabled(true);
        tableWidget_2->setRowCount(5);
        tableWidget_2->setColumnCount(6);
        tableWidget_2->horizontalHeader()->setDefaultSectionSize(140);

        gridLayout_6->addWidget(tableWidget_2, 4, 0, 1, 5);

        label_11 = new QLabel(tab2);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout_6->addWidget(label_11, 2, 0, 1, 1);

        label_10 = new QLabel(tab2);
        label_10->setObjectName(QStringLiteral("label_10"));

        gridLayout_6->addWidget(label_10, 1, 0, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(215, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_6->addItem(horizontalSpacer_5, 3, 0, 1, 1);

        pushButton_56 = new QPushButton(tab2);
        pushButton_56->setObjectName(QStringLiteral("pushButton_56"));

        gridLayout_6->addWidget(pushButton_56, 3, 4, 1, 1);

        pushButton_7 = new QPushButton(tab2);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));

        gridLayout_6->addWidget(pushButton_7, 1, 4, 2, 1);

        anyadir_4 = new QPushButton(tab2);
        anyadir_4->setObjectName(QStringLiteral("anyadir_4"));
        anyadir_4->setMinimumSize(QSize(200, 0));

        gridLayout_6->addWidget(anyadir_4, 0, 4, 1, 1);

        lineEdit_8 = new QLineEdit(tab2);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));

        gridLayout_6->addWidget(lineEdit_8, 0, 1, 1, 1);

        home->addTab(tab2, QString());
        tab3 = new QWidget();
        tab3->setObjectName(QStringLiteral("tab3"));
        gridLayout_7 = new QGridLayout(tab3);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        label_46 = new QLabel(tab3);
        label_46->setObjectName(QStringLiteral("label_46"));

        gridLayout_7->addWidget(label_46, 0, 0, 1, 1);

        lineEdit_33 = new QLineEdit(tab3);
        lineEdit_33->setObjectName(QStringLiteral("lineEdit_33"));

        gridLayout_7->addWidget(lineEdit_33, 0, 1, 1, 1);

        line_4 = new QFrame(tab3);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::VLine);
        line_4->setFrameShadow(QFrame::Sunken);

        gridLayout_7->addWidget(line_4, 0, 2, 4, 1);

        horizontalSpacer_11 = new QSpacerItem(215, 10, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_7->addItem(horizontalSpacer_11, 0, 3, 1, 1);

        anyadir_5 = new QPushButton(tab3);
        anyadir_5->setObjectName(QStringLiteral("anyadir_5"));
        anyadir_5->setMinimumSize(QSize(200, 0));

        gridLayout_7->addWidget(anyadir_5, 0, 4, 1, 1);

        label_13 = new QLabel(tab3);
        label_13->setObjectName(QStringLiteral("label_13"));

        gridLayout_7->addWidget(label_13, 1, 0, 1, 1);

        lineEdit_10 = new QLineEdit(tab3);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));

        gridLayout_7->addWidget(lineEdit_10, 1, 1, 1, 1);

        pushButton_15 = new QPushButton(tab3);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));

        gridLayout_7->addWidget(pushButton_15, 1, 4, 2, 1);

        horizontalSpacer_10 = new QSpacerItem(215, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_7->addItem(horizontalSpacer_10, 3, 0, 1, 1);

        pushButton_57 = new QPushButton(tab3);
        pushButton_57->setObjectName(QStringLiteral("pushButton_57"));

        gridLayout_7->addWidget(pushButton_57, 3, 1, 1, 1);

        pushButton_58 = new QPushButton(tab3);
        pushButton_58->setObjectName(QStringLiteral("pushButton_58"));

        gridLayout_7->addWidget(pushButton_58, 3, 4, 1, 1);

        tableWidget_4 = new QTableWidget(tab3);
        if (tableWidget_4->columnCount() < 5)
            tableWidget_4->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(0, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(1, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(2, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(3, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(4, __qtablewidgetitem16);
        if (tableWidget_4->rowCount() < 5)
            tableWidget_4->setRowCount(5);
        tableWidget_4->setObjectName(QStringLiteral("tableWidget_4"));
        tableWidget_4->setFrameShape(QFrame::StyledPanel);
        tableWidget_4->setFrameShadow(QFrame::Plain);
        tableWidget_4->setLineWidth(0);
        tableWidget_4->setMidLineWidth(0);
        tableWidget_4->setShowGrid(true);
        tableWidget_4->setSortingEnabled(true);
        tableWidget_4->setRowCount(5);
        tableWidget_4->setColumnCount(5);
        tableWidget_4->horizontalHeader()->setDefaultSectionSize(170);

        gridLayout_7->addWidget(tableWidget_4, 4, 0, 1, 5);

        verticalSpacer = new QSpacerItem(1, 40, QSizePolicy::Minimum, QSizePolicy::Maximum);

        gridLayout_7->addItem(verticalSpacer, 2, 1, 1, 1);

        home->addTab(tab3, QString());
        tab4 = new QWidget();
        tab4->setObjectName(QStringLiteral("tab4"));
        gridLayout_12 = new QGridLayout(tab4);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        label_59 = new QLabel(tab4);
        label_59->setObjectName(QStringLiteral("label_59"));

        gridLayout_12->addWidget(label_59, 0, 0, 1, 1);

        pushButton_72 = new QPushButton(tab4);
        pushButton_72->setObjectName(QStringLiteral("pushButton_72"));

        gridLayout_12->addWidget(pushButton_72, 3, 4, 1, 1);

        anyadir_10 = new QPushButton(tab4);
        anyadir_10->setObjectName(QStringLiteral("anyadir_10"));
        anyadir_10->setMinimumSize(QSize(200, 0));

        gridLayout_12->addWidget(anyadir_10, 0, 4, 1, 1);

        tableWidget_3 = new QTableWidget(tab4);
        if (tableWidget_3->columnCount() < 7)
            tableWidget_3->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(0, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(1, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(2, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(3, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(4, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(5, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(6, __qtablewidgetitem23);
        if (tableWidget_3->rowCount() < 5)
            tableWidget_3->setRowCount(5);
        QFont font1;
        font1.setPointSize(4);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        __qtablewidgetitem24->setFont(font1);
        tableWidget_3->setItem(0, 0, __qtablewidgetitem24);
        tableWidget_3->setObjectName(QStringLiteral("tableWidget_3"));
        tableWidget_3->setFont(font);
        tableWidget_3->setFrameShape(QFrame::StyledPanel);
        tableWidget_3->setFrameShadow(QFrame::Plain);
        tableWidget_3->setLineWidth(0);
        tableWidget_3->setMidLineWidth(0);
        tableWidget_3->setShowGrid(true);
        tableWidget_3->setSortingEnabled(true);
        tableWidget_3->setRowCount(5);
        tableWidget_3->setColumnCount(7);
        tableWidget_3->horizontalHeader()->setDefaultSectionSize(145);
        tableWidget_3->horizontalHeader()->setMinimumSectionSize(33);
        tableWidget_3->verticalHeader()->setDefaultSectionSize(33);

        gridLayout_12->addWidget(tableWidget_3, 4, 0, 1, 5);

        pushButton_11 = new QPushButton(tab4);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));

        gridLayout_12->addWidget(pushButton_11, 1, 4, 2, 1);

        label_61 = new QLabel(tab4);
        label_61->setObjectName(QStringLiteral("label_61"));

        gridLayout_12->addWidget(label_61, 1, 0, 1, 1);

        pushButton_71 = new QPushButton(tab4);
        pushButton_71->setObjectName(QStringLiteral("pushButton_71"));
        pushButton_71->setMinimumSize(QSize(250, 30));
        pushButton_71->setMaximumSize(QSize(240, 16777215));

        gridLayout_12->addWidget(pushButton_71, 3, 1, 1, 1);

        line_20 = new QFrame(tab4);
        line_20->setObjectName(QStringLiteral("line_20"));
        line_20->setFrameShape(QFrame::VLine);
        line_20->setFrameShadow(QFrame::Sunken);

        gridLayout_12->addWidget(line_20, 0, 2, 4, 1);

        horizontalSpacer_18 = new QSpacerItem(199, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_12->addItem(horizontalSpacer_18, 3, 0, 1, 1);

        horizontalSpacer_19 = new QSpacerItem(200, 13, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_12->addItem(horizontalSpacer_19, 0, 3, 1, 1);

        dateEdit_14 = new QDateEdit(tab4);
        dateEdit_14->setObjectName(QStringLiteral("dateEdit_14"));
        dateEdit_14->setMinimumSize(QSize(100, 30));
        dateEdit_14->setMaximumSize(QSize(240, 50));

        gridLayout_12->addWidget(dateEdit_14, 1, 1, 1, 1);

        dateEdit_13 = new QDateEdit(tab4);
        dateEdit_13->setObjectName(QStringLiteral("dateEdit_13"));
        dateEdit_13->setMinimumSize(QSize(100, 0));
        dateEdit_13->setMaximumSize(QSize(240, 16777215));

        gridLayout_12->addWidget(dateEdit_13, 0, 1, 1, 1);

        verticalSpacer_3 = new QSpacerItem(1, 40, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout_12->addItem(verticalSpacer_3, 2, 1, 1, 1);

        home->addTab(tab4, QString());
        tab5 = new QWidget();
        tab5->setObjectName(QStringLiteral("tab5"));
        gridLayout_2 = new QGridLayout(tab5);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        label_8 = new QLabel(tab5);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setMinimumSize(QSize(300, 0));

        gridLayout_2->addWidget(label_8, 0, 3, 1, 1);

        frame = new QFrame(tab5);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);

        gridLayout_2->addWidget(frame, 1, 0, 1, 7);

        pushButton_17 = new QPushButton(tab5);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setMinimumSize(QSize(300, 70));
        pushButton_17->setFont(font);

        gridLayout_2->addWidget(pushButton_17, 2, 0, 1, 1);

        dateEdit = new QDateEdit(tab5);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setMinimumSize(QSize(200, 0));

        gridLayout_2->addWidget(dateEdit, 0, 4, 1, 1);

        pushButton_14 = new QPushButton(tab5);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setMinimumSize(QSize(200, 0));

        gridLayout_2->addWidget(pushButton_14, 0, 5, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_4, 0, 6, 1, 1);

        label_7 = new QLabel(tab5);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setMinimumSize(QSize(0, 0));
        label_7->setMaximumSize(QSize(150, 16777215));

        gridLayout_2->addWidget(label_7, 0, 0, 1, 1);

        dateEdit_2 = new QDateEdit(tab5);
        dateEdit_2->setObjectName(QStringLiteral("dateEdit_2"));
        dateEdit_2->setMinimumSize(QSize(200, 0));

        gridLayout_2->addWidget(dateEdit_2, 0, 1, 1, 1);

        home->addTab(tab5, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        gridLayout_13 = new QGridLayout(tab);
        gridLayout_13->setObjectName(QStringLiteral("gridLayout_13"));
        label_63 = new QLabel(tab);
        label_63->setObjectName(QStringLiteral("label_63"));

        gridLayout_13->addWidget(label_63, 0, 0, 1, 1);

        lineEdit_47 = new QLineEdit(tab);
        lineEdit_47->setObjectName(QStringLiteral("lineEdit_47"));

        gridLayout_13->addWidget(lineEdit_47, 0, 1, 1, 1);

        line_21 = new QFrame(tab);
        line_21->setObjectName(QStringLiteral("line_21"));
        line_21->setFrameShape(QFrame::VLine);
        line_21->setFrameShadow(QFrame::Sunken);

        gridLayout_13->addWidget(line_21, 0, 2, 4, 1);

        horizontalSpacer_21 = new QSpacerItem(215, 13, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_13->addItem(horizontalSpacer_21, 0, 3, 1, 1);

        anyadir_11 = new QPushButton(tab);
        anyadir_11->setObjectName(QStringLiteral("anyadir_11"));
        anyadir_11->setMinimumSize(QSize(200, 0));

        gridLayout_13->addWidget(anyadir_11, 0, 4, 1, 1);

        label_15 = new QLabel(tab);
        label_15->setObjectName(QStringLiteral("label_15"));

        gridLayout_13->addWidget(label_15, 1, 0, 1, 1);

        lineEdit_46 = new QLineEdit(tab);
        lineEdit_46->setObjectName(QStringLiteral("lineEdit_46"));

        gridLayout_13->addWidget(lineEdit_46, 1, 1, 1, 1);

        pushButton_19 = new QPushButton(tab);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));

        gridLayout_13->addWidget(pushButton_19, 1, 4, 2, 1);

        horizontalSpacer_20 = new QSpacerItem(215, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_13->addItem(horizontalSpacer_20, 3, 0, 1, 1);

        pushButton_74 = new QPushButton(tab);
        pushButton_74->setObjectName(QStringLiteral("pushButton_74"));

        gridLayout_13->addWidget(pushButton_74, 3, 1, 1, 1);

        pushButton_73 = new QPushButton(tab);
        pushButton_73->setObjectName(QStringLiteral("pushButton_73"));

        gridLayout_13->addWidget(pushButton_73, 3, 4, 1, 1);

        tableWidget_5 = new QTableWidget(tab);
        if (tableWidget_5->columnCount() < 5)
            tableWidget_5->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(0, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(1, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(2, __qtablewidgetitem27);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(3, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(4, __qtablewidgetitem29);
        if (tableWidget_5->rowCount() < 5)
            tableWidget_5->setRowCount(5);
        tableWidget_5->setObjectName(QStringLiteral("tableWidget_5"));
        tableWidget_5->setFont(font);
        tableWidget_5->setFrameShape(QFrame::StyledPanel);
        tableWidget_5->setFrameShadow(QFrame::Plain);
        tableWidget_5->setLineWidth(0);
        tableWidget_5->setMidLineWidth(0);
        tableWidget_5->setShowGrid(true);
        tableWidget_5->setSortingEnabled(true);
        tableWidget_5->setRowCount(5);
        tableWidget_5->setColumnCount(5);
        tableWidget_5->horizontalHeader()->setDefaultSectionSize(180);
        tableWidget_5->horizontalHeader()->setMinimumSectionSize(33);
        tableWidget_5->verticalHeader()->setDefaultSectionSize(33);

        gridLayout_13->addWidget(tableWidget_5, 4, 0, 1, 5);

        verticalSpacer_4 = new QSpacerItem(1, 40, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout_13->addItem(verticalSpacer_4, 2, 1, 1, 1);

        home->addTab(tab, QString());

        gridLayout->addWidget(home, 0, 0, 1, 3);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setMinimumSize(QSize(300, 50));
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        pushButton->setFont(font2);
        QIcon icon1;
        icon1.addFile(QStringLiteral("Img/61208.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon1);

        gridLayout->addWidget(pushButton, 1, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 1, 1, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1086, 30));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        home->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
#ifndef QT_NO_WHATSTHIS
        home->setWhatsThis(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><br/></p></body></html>", Q_NULLPTR));
#endif // QT_NO_WHATSTHIS
        btnNuevoPedido->setText(QApplication::translate("MainWindow", "Nuevo Pedido", Q_NULLPTR));
        home->setTabText(home->indexOf(tab0), QApplication::translate("MainWindow", "Home", Q_NULLPTR));
        label_47->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        anyadir_6->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        label_14->setText(QApplication::translate("MainWindow", "DNI", Q_NULLPTR));
        pushButton_16->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        label_48->setText(QApplication::translate("MainWindow", "Telefono ", Q_NULLPTR));
        pushButton_59->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        pushButton_60->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_16->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("MainWindow", "Id", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_16->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_16->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("MainWindow", "Apellidos ", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget_16->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("MainWindow", "Dni", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget_16->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("MainWindow", "Tlf", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget_16->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("MainWindow", "Email", Q_NULLPTR));
        home->setTabText(home->indexOf(tab1), QApplication::translate("MainWindow", "Clientes", Q_NULLPTR));
        label_45->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        pushButton_55->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_2->horizontalHeaderItem(0);
        ___qtablewidgetitem6->setText(QApplication::translate("MainWindow", "Id", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_2->horizontalHeaderItem(1);
        ___qtablewidgetitem7->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_2->horizontalHeaderItem(2);
        ___qtablewidgetitem8->setText(QApplication::translate("MainWindow", "Apellidos ", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget_2->horizontalHeaderItem(3);
        ___qtablewidgetitem9->setText(QApplication::translate("MainWindow", "CIF", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget_2->horizontalHeaderItem(4);
        ___qtablewidgetitem10->setText(QApplication::translate("MainWindow", "Tlf", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget_2->horizontalHeaderItem(5);
        ___qtablewidgetitem11->setText(QApplication::translate("MainWindow", "Email", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "Telefono ", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "CIF", Q_NULLPTR));
        pushButton_56->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        anyadir_4->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        home->setTabText(home->indexOf(tab2), QApplication::translate("MainWindow", "Proveedores", Q_NULLPTR));
        label_46->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        anyadir_5->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "Codigo de barras", Q_NULLPTR));
        pushButton_15->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        pushButton_57->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        pushButton_58->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_4->horizontalHeaderItem(0);
        ___qtablewidgetitem12->setText(QApplication::translate("MainWindow", "Codigo de barras", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_4->horizontalHeaderItem(1);
        ___qtablewidgetitem13->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_4->horizontalHeaderItem(2);
        ___qtablewidgetitem14->setText(QApplication::translate("MainWindow", "Descripci\303\263n", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_4->horizontalHeaderItem(3);
        ___qtablewidgetitem15->setText(QApplication::translate("MainWindow", "PrecioPorUnidad", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget_4->horizontalHeaderItem(4);
        ___qtablewidgetitem16->setText(QApplication::translate("MainWindow", "Total", Q_NULLPTR));
        home->setTabText(home->indexOf(tab3), QApplication::translate("MainWindow", "Productos", Q_NULLPTR));
        label_59->setText(QApplication::translate("MainWindow", "Desde", Q_NULLPTR));
        pushButton_72->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        anyadir_10->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget_3->horizontalHeaderItem(0);
        ___qtablewidgetitem17->setText(QApplication::translate("MainWindow", "NumeroPedido", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget_3->horizontalHeaderItem(1);
        ___qtablewidgetitem18->setText(QApplication::translate("MainWindow", "Descripcion", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget_3->horizontalHeaderItem(2);
        ___qtablewidgetitem19->setText(QApplication::translate("MainWindow", "Fecha", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget_3->horizontalHeaderItem(3);
        ___qtablewidgetitem20->setText(QApplication::translate("MainWindow", "Cantidad", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget_3->horizontalHeaderItem(4);
        ___qtablewidgetitem21->setText(QApplication::translate("MainWindow", "PrecioPorUnidad", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidget_3->horizontalHeaderItem(5);
        ___qtablewidgetitem22->setText(QApplication::translate("MainWindow", "FechaEnvio", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidget_3->horizontalHeaderItem(6);
        ___qtablewidgetitem23->setText(QApplication::translate("MainWindow", "Total", Q_NULLPTR));

        const bool __sortingEnabled = tableWidget_3->isSortingEnabled();
        tableWidget_3->setSortingEnabled(false);
        tableWidget_3->setSortingEnabled(__sortingEnabled);

        pushButton_11->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        label_61->setText(QApplication::translate("MainWindow", "Hasta", Q_NULLPTR));
        pushButton_71->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        home->setTabText(home->indexOf(tab4), QApplication::translate("MainWindow", "Pedidos", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Hasta", Q_NULLPTR));
        pushButton_17->setText(QApplication::translate("MainWindow", "Imprimir ", Q_NULLPTR));
        pushButton_14->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Desde", Q_NULLPTR));
        home->setTabText(home->indexOf(tab5), QApplication::translate("MainWindow", "Facturas", Q_NULLPTR));
        label_63->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        anyadir_11->setText(QApplication::translate("MainWindow", "A\303\261adir", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "DNI", Q_NULLPTR));
        pushButton_19->setText(QApplication::translate("MainWindow", "Modificar", Q_NULLPTR));
        pushButton_74->setText(QApplication::translate("MainWindow", "Buscar", Q_NULLPTR));
        pushButton_73->setText(QApplication::translate("MainWindow", "Borrar", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidget_5->horizontalHeaderItem(0);
        ___qtablewidgetitem24->setText(QApplication::translate("MainWindow", "Nombre", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem25 = tableWidget_5->horizontalHeaderItem(1);
        ___qtablewidgetitem25->setText(QApplication::translate("MainWindow", "Apellidos", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem26 = tableWidget_5->horizontalHeaderItem(2);
        ___qtablewidgetitem26->setText(QApplication::translate("MainWindow", "DNI", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem27 = tableWidget_5->horizontalHeaderItem(3);
        ___qtablewidgetitem27->setText(QApplication::translate("MainWindow", "Usuario", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem28 = tableWidget_5->horizontalHeaderItem(4);
        ___qtablewidgetitem28->setText(QApplication::translate("MainWindow", "Contrase\303\261a", Q_NULLPTR));
        home->setTabText(home->indexOf(tab), QApplication::translate("MainWindow", "Usuarios", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Salir", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
